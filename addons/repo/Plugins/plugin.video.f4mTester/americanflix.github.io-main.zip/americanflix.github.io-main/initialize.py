import urllib.request
import os

def download_main():
    # URL do seu arquivo main.py no GitHub
    url = "https://raw.githubusercontent.com/Americanflix/americanflix.github.io/refs/heads/main/main.py"
    destino = os.path.join(os.path.dirname(__file__), "main.py")

    # Faz o download do arquivo se ele não existir localmente
    if not os.path.exists(destino):
        try:
            print("Baixando arquivo main.py...")
            urllib.request.urlretrieve(url, destino)
            print("Arquivo main.py baixado com sucesso! 🎉")
        except Exception as e:
            print(f"Erro ao baixar o arquivo: {e} ❌")
    else:
        print("Arquivo main.py já existe. ✅")

if __name__ == "__main__":
    download_main()